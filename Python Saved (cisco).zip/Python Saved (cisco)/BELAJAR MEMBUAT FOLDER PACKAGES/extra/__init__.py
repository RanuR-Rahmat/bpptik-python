value = 1
value /= 0