import math
for name in dir(math):
    print(name, end="\t")
