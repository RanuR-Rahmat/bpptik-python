bil=1
while bil=1:
    print(bil)
    bil=bil+2
else:
    print("akhir while")
