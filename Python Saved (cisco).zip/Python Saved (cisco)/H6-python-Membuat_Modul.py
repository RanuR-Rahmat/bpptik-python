print("Null")
