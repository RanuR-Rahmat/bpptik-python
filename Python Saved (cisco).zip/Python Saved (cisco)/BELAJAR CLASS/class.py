class contohclass:
    def cetak(self):
        print("cntohclass")
    cetak('')
    pass
conobj=contohclass()
conobj2=contohclass()
conobj3=contohclass()
