from ranur  import counter,a

print(a)
