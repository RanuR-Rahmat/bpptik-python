counter  =0

if __name__ == "__main__":
    print("I prefer to be a Modules")
else:
    print("I run from any extension Module")
